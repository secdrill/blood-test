# AADInternals
AADInternals is PowerShell module for administering Azure AD and Office 365

For details, please visit https://aadinternals.com/aadinternals

## Installation
Run the following PowerShell command to install
```
Install-Module AADInternals
```
